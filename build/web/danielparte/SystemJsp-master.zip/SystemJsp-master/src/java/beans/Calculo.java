package beans;

public class Calculo {
    
    public double ConverterDolar(double n){
        return (n / 3.57);
    }
    
    public double ConverterEuro(double x){
        return (x /4.25 );
    }
}
